<?php
function gutenberg_market_licensing() {
    return;
}
